#!/bin/bash

# Install libmysqlclient-dev for mysqlclient
apt-get update && apt-get install -y libmysqlclient-dev
